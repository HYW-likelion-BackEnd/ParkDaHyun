from django.shortcuts import render
from .models import Todo

# Create your views here.
# 목록 화면 뷰
def todo_list(request):
    todos = Todo.objects.filter(complete=False)
    return render(request, 'todo/todo_list.html',{'todos':todos})

# 상세 조회 뷰
def todo_detail (request,pk):
    todo = Todo.objects.get(id=pk)
    return render (request, 'todo/todo_detail.html', {'todo':todo})